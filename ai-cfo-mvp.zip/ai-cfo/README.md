# AI CFO — MVP (build in progress)

An AI-powered financial operating system for Indian MSMEs (₹1cr–₹25cr turnover),
built to answer: **what happened → what's likely to happen → what should I do**.

## What's built so far (Steps 1–9 of the plan)

**Architecture & repo**
- Next.js 14 (App Router) + TypeScript, Tailwind, Prisma/PostgreSQL — `/app`, `/lib`, `/components`, `/prisma`, `/tests`
- Clean separation: UI (`app`, `components`) never contains financial math or DB calls directly

**Database** (`prisma/schema.prisma`)
- Full schema: Users, Businesses, BusinessMember (RBAC), Customers, Suppliers, Products, Invoices,
  InvoiceItems, Payments, Expenses, BankTransactions, Loans, InventoryItems, Employees,
  FinancialMetrics, CashFlowForecasts, Insights, AIConversations/AIMessages, Integrations, AuditLogs

**Financial calculation engine** (`lib/finance/calculations.ts` + `tests/calculations.test.ts`)
- Deterministic, unit-tested functions for revenue, COGS, gross margin, EBITDA, current ratio,
  DSO/DPO/DIO, cash conversion cycle, working capital, funding gap, cash burn/runway,
  receivables aging, payment reliability, and the composite Business Health Score
- **The LLM never computes a number** — it only reads output from this engine, via tools

**AI CFO** (`lib/ai/`)
- `provider.ts` — swappable LLM backend (no provider hardcoded; `AI_PROVIDER` env var)
- `providers/anthropic-provider.ts` — first adapter
- `tools.ts` — 8 typed financial tools (getRevenue, getCashBalance, getReceivables, getPayables,
  getCustomerProfitability, getCashForecast, getWorkingCapital, getFinancialRisks), each backed
  by real Prisma queries + the calc engine. Returns `{ available: false }` when there's no data.
- `cfo-agent.ts` — the agent loop + system prompt that forces grounded, structured answers
  (Finding / Evidence / Impact / Recommendation) and forbids inventing figures

**Auth & security** (`lib/auth/`)
- bcrypt password hashing, JWT sessions (httpOnly cookies), role-based permissions
  (Owner/Admin/CFO/Accountant/Finance Manager/Viewer), in-memory rate limiting, audit logging
  on signup and every AI CFO query, zod input validation on every API route

**API routes**
- `POST /api/auth/signup`, `POST /api/auth/login`, `POST /api/ai/chat`

**Demo company** (`prisma/seed.ts`)
- "ABC Manufacturing Pvt Ltd" — 25 customers, 42 suppliers, 78 employees, 12 months of sales
  and purchase invoices with realistic payment behavior, a full year of bank transactions,
  a term loan, inventory, monthly rolled-up FinancialMetrics, 90-day cash forecasts in
  base/optimistic/stress scenarios, and 4 pre-seeded insights matching the brief
- Demo login: `owner@abcmanufacturing.demo` / `Demo@1234`

**UI**
- Landing page (`app/(marketing)/page.tsx`) — ledger-inspired design system (see Design notes below)
- Login / Signup pages
- Business Health dashboard (`app/(dashboard)/dashboard/page.tsx`) — score, 10 core metrics,
  cash trend chart, "what needs your attention" alerts

## Design notes

The visual system is deliberately *not* a generic SaaS-fintech template: warm paper background,
navy ink text, a single ledger-gold accent, Fraunces (serif, display) paired with Inter (body) and
IBM Plex Mono (numbers), a subtle ruled-paper texture, and "folio" numbering in the marketing copy —
all drawn from the ledger/accounting subject matter itself. Tokens live in `tailwind.config.ts`.

## Running it locally

This sandbox has no network access, so dependencies could not be installed or the app run here —
the calculation engine's logic was hand-verified instead. To run it yourself:

```bash
npm install
cp .env.example .env        # fill in DATABASE_URL, SESSION_SECRET, ANTHROPIC_API_KEY
npx prisma db push          # creates tables from schema.prisma
npm run db:seed             # populates the demo company
npm run dev                 # http://localhost:3000
npm test                    # runs tests/calculations.test.ts
```

`SESSION_SECRET`: generate with `openssl rand -base64 32`.
`DATABASE_URL`: any Postgres 14+ instance (local, Supabase, Neon, RDS...).

## What's next (Steps 10–15 of your plan)

Not yet built — tell me which to do next, or say "continue" and I'll proceed in order:

10. Receivables & Payables pages (aging tables, customer risk profiles, "safe to delay" logic)
11. Profitability views (by customer/product/channel)
12. Working capital & Financing module (illustrative-only, mock lender options)
13. CSV/Excel upload with automatic column mapping
14. AI Insights page, Reports (PDF/CSV export), Settings, mock GST/Tally/Zoho/AA integration screens
15. Business onboarding flow UI, mobile responsiveness pass, remaining test coverage

## Regulatory note

This product is designed as financial insight / decision-support software. It does not present
itself as a bank, NBFC, lender, payment system, or investment adviser, and all financing content
is labeled illustrative and subject to lender approval, per the brief.
