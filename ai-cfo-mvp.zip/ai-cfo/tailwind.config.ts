import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#101826", // near-black navy — primary text & dark surfaces
          50: "#F4F5F7",
          100: "#E4E7EC",
          400: "#5B6472",
          700: "#1B2434",
          900: "#101826",
        },
        paper: "#FAF9F6", // warm off-white base, not stark white
        ledger: {
          gold: "#B8863B", // signal accent — ledger-ink gold, used sparingly
          sage: "#3F6357", // positive / healthy
          brick: "#A23E2C", // risk / overdue
          slate: "#6B7785", // neutral secondary text
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      backgroundImage: {
        "ledger-rule":
          "repeating-linear-gradient(to bottom, transparent, transparent 34px, rgba(16,24,38,0.05) 35px)",
      },
      borderRadius: {
        card: "10px",
      },
      boxShadow: {
        card: "0 1px 2px rgba(16,24,38,0.04), 0 8px 24px -12px rgba(16,24,38,0.10)",
      },
    },
  },
  plugins: [],
};

export default config;
