import { describe, it, expect } from "vitest";
import {
  revenue,
  cogs,
  grossProfit,
  grossMarginPct,
  ebitda,
  currentRatio,
  receivableDays,
  payableDays,
  inventoryDays,
  cashConversionCycle,
  workingCapital,
  requiredWorkingCapital,
  fundingGap,
  cashBurnPerDay,
  cashRunwayDays,
  agingBucket,
  agingSchedule,
  paymentReliability,
  businessHealthScore,
} from "../lib/finance/calculations";

describe("P&L basics", () => {
  const lines = [
    { quantity: 10, unitPrice: 100, unitCost: 60 },
    { quantity: 5, unitPrice: 200, unitCost: 120 },
  ];

  it("computes revenue", () => {
    expect(revenue(lines)).toBe(2000);
  });

  it("computes COGS", () => {
    expect(cogs(lines)).toBe(1200);
  });

  it("computes gross profit and margin", () => {
    const rev = revenue(lines);
    const cost = cogs(lines);
    expect(grossProfit(rev, cost)).toBe(800);
    expect(grossMarginPct(rev, cost)).toBe(40);
  });

  it("computes EBITDA", () => {
    expect(ebitda(800, 300)).toBe(500);
  });

  it("handles zero revenue without dividing by zero", () => {
    expect(grossMarginPct(0, 0)).toBe(0);
  });
});

describe("Liquidity and working capital", () => {
  it("computes current ratio", () => {
    expect(currentRatio(200000, 100000)).toBe(2);
  });

  it("computes receivable/payable/inventory days", () => {
    expect(receivableDays(500000, 3000000, 90)).toBe(15);
    expect(payableDays(300000, 2000000, 90)).toBe(13.5);
    expect(inventoryDays(400000, 2000000, 90)).toBe(18);
  });

  it("computes cash conversion cycle", () => {
    expect(cashConversionCycle(18, 15, 13.5)).toBe(19.5);
  });

  it("computes working capital", () => {
    expect(workingCapital(500000, 300000)).toBe(200000);
  });

  it("sizes required working capital from CCC and daily burn", () => {
    // CCC 20 days, average daily outflow 50,000 => 10,00,000 required
    expect(requiredWorkingCapital(20, 50000)).toBe(1000000);
    expect(requiredWorkingCapital(-5, 50000)).toBe(0); // negative CCC needs no WC
  });

  it("computes funding gap only when required exceeds available", () => {
    expect(fundingGap(1200000, 800000)).toBe(400000);
    expect(fundingGap(500000, 800000)).toBe(0);
  });
});

describe("Cash burn and runway", () => {
  it("computes burn per day", () => {
    expect(cashBurnPerDay(-90000, 30)).toBe(-3000);
  });

  it("computes runway only when burning cash", () => {
    expect(cashRunwayDays(1500000, -30000)).toBe(50);
    expect(cashRunwayDays(1500000, 10000)).toBeNull();
  });
});

describe("Receivables aging", () => {
  const asOf = new Date("2026-08-13");

  it("buckets a not-yet-due invoice as current", () => {
    expect(agingBucket(new Date("2026-08-20"), asOf)).toBe("current");
  });

  it("buckets overdue invoices correctly", () => {
    expect(agingBucket(new Date("2026-08-01"), asOf)).toBe("1-30");
    expect(agingBucket(new Date("2026-06-20"), asOf)).toBe("31-60");
    expect(agingBucket(new Date("2026-05-10"), asOf)).toBe("61-90");
    expect(agingBucket(new Date("2026-01-01"), asOf)).toBe("90+");
  });

  it("builds an aging schedule ignoring fully paid invoices", () => {
    const invoices = [
      { amount: 100000, amountPaid: 0, dueDate: new Date("2026-08-01") },
      { amount: 50000, amountPaid: 50000, dueDate: new Date("2026-07-01") }, // fully paid, excluded
      { amount: 200000, amountPaid: 100000, dueDate: new Date("2026-05-01") },
    ];
    const schedule = agingSchedule(invoices, asOf);
    expect(schedule["1-30"]).toBe(100000);
    expect(schedule["61-90"]).toBe(100000);
    expect(schedule["current"]).toBe(0);
  });

  it("computes payment reliability", () => {
    expect(paymentReliability(87, 100)).toBe(87);
    expect(paymentReliability(0, 0)).toBe(0);
  });
});

describe("Business health score", () => {
  it("scores a healthy business highly", () => {
    const result = businessHealthScore({
      cashRunwayDays: null, // not burning cash
      grossMarginPct: 35,
      currentRatio: 1.8,
      receivableDaysTrendDelta: 2,
      debtServiceCoverageRatio: 2.5,
      customerConcentrationPct: 18,
      inventoryDaysTrendDelta: 3,
      revenueGrowthPct: 14,
    });
    expect(result.score).toBeGreaterThan(75);
    expect(result.score).toBeLessThanOrEqual(100);
  });

  it("scores a distressed business low", () => {
    const result = businessHealthScore({
      cashRunwayDays: 12,
      grossMarginPct: 8,
      currentRatio: 0.6,
      receivableDaysTrendDelta: 28,
      debtServiceCoverageRatio: 0.6,
      customerConcentrationPct: 55,
      inventoryDaysTrendDelta: 25,
      revenueGrowthPct: -8,
    });
    expect(result.score).toBeLessThan(35);
  });

  it("always returns a score between 0 and 100", () => {
    const result = businessHealthScore({
      cashRunwayDays: 0,
      grossMarginPct: -50,
      currentRatio: 0,
      receivableDaysTrendDelta: 100,
      debtServiceCoverageRatio: 0,
      customerConcentrationPct: 100,
      inventoryDaysTrendDelta: 100,
      revenueGrowthPct: -100,
    });
    expect(result.score).toBeGreaterThanOrEqual(0);
    expect(result.score).toBeLessThanOrEqual(100);
  });
});
