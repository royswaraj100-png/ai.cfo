import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { cookies } from "next/headers";
import { prisma } from "@/lib/db/client";
import { verifySessionToken, SESSION_COOKIE_NAME } from "@/lib/auth/session";
import { hasPermission } from "@/lib/auth/rbac";
import { runCFOAgent } from "@/lib/ai/cfo-agent";
import { checkRateLimit } from "@/lib/auth/rate-limit";

const chatSchema = z.object({
  businessId: z.string(),
  conversationId: z.string().optional(),
  message: z.string().min(1).max(2000),
});

export async function POST(req: NextRequest) {
  const token = cookies().get(SESSION_COOKIE_NAME)?.value;
  const session = token ? await verifySessionToken(token) : null;
  if (!session) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }

  const limited = checkRateLimit(`ai-chat:${session.userId}`, 30, 60_000);
  if (!limited.allowed) {
    return NextResponse.json({ error: "Too many requests. Please slow down." }, { status: 429 });
  }

  const parsed = chatSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input", details: parsed.error.flatten() }, { status: 400 });
  }
  const { businessId, message } = parsed.data;

  const membership = await prisma.businessMember.findUnique({
    where: { userId_businessId: { userId: session.userId, businessId } },
  });
  if (!membership || !hasPermission(membership.role, "use:ai-cfo")) {
    return NextResponse.json({ error: "Not authorized for this business." }, { status: 403 });
  }

  let conversationId = parsed.data.conversationId;
  if (!conversationId) {
    const convo = await prisma.aIConversation.create({
      data: { businessId, userId: session.userId, title: message.slice(0, 60) },
    });
    conversationId = convo.id;
  }

  await prisma.aIMessage.create({
    data: { conversationId, role: "USER", content: message },
  });

  const priorMessages = await prisma.aIMessage.findMany({
    where: { conversationId },
    orderBy: { createdAt: "asc" },
    take: 20,
  });

  const result = await runCFOAgent(
    businessId,
    priorMessages.map((m) => ({ role: m.role.toLowerCase() as "user" | "assistant", content: m.content }))
  );

  await prisma.aIMessage.create({
    data: {
      conversationId,
      role: "ASSISTANT",
      content: result.text,
      toolCalls: result.toolCallLog as any,
    },
  });

  await prisma.auditLog.create({
    data: {
      businessId,
      userId: session.userId,
      action: "AI_CFO_QUERY",
      metadata: { toolCalls: result.toolCallLog.map((t) => t.name) },
    },
  });

  return NextResponse.json({ conversationId, reply: result.text, toolCalls: result.toolCallLog });
}
