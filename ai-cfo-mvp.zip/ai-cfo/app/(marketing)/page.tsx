import Link from "next/link";

const folios = [
  {
    n: "01",
    title: "What happened",
    body: "Every rupee in and out, reconciled into revenue, margin, cash, receivables and payables — reported the way a CFO would, not the way a ledger dumps it.",
  },
  {
    n: "02",
    title: "What's likely to happen",
    body: "A 30- and 90-day cash forecast in base, optimistic and stress cases, so a cash shortfall is a warning you get weeks early, not a surprise on the day.",
  },
  {
    n: "03",
    title: "What you should do",
    body: "Every alert ships with a reason, an impact in rupees, and a next step — delay this payment, chase this customer, size this financing.",
  },
];

const attentionItems = [
  { level: "critical", text: "Cash deficit expected in 18 days" },
  { level: "warning", text: "Customer Sharma Textiles has ₹12.4L overdue" },
  { level: "warning", text: "Gross margin declined 2.1% this month" },
  { level: "info", text: "Inventory increased 16% vs last quarter" },
];

const levelColor: Record<string, string> = {
  critical: "bg-ledger-brick",
  warning: "bg-ledger-gold",
  info: "bg-ledger-slate",
};

export default function LandingPage() {
  return (
    <main className="bg-ledger-rule">
      {/* Nav */}
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <span className="font-display text-xl italic tracking-tight">AI CFO</span>
        <nav className="hidden gap-8 font-body text-sm text-ledger-slate md:flex">
          <a href="#how-it-works" className="hover:text-ink">How it works</a>
          <a href="#security" className="hover:text-ink">Security</a>
          <a href="#pricing" className="hover:text-ink">Pricing</a>
        </nav>
        <div className="flex items-center gap-4">
          <Link href="/login" className="text-sm text-ledger-slate hover:text-ink">Log in</Link>
          <Link
            href="/signup"
            className="rounded-card bg-ink px-4 py-2 text-sm font-medium text-paper hover:bg-ink-700"
          >
            Start free
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="mx-auto grid max-w-6xl gap-12 px-6 pb-20 pt-10 md:grid-cols-2 md:items-center">
        <div>
          <p className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-ledger-gold">
            Folio 001 — Business Health
          </p>
          <h1 className="font-display text-4xl leading-[1.1] tracking-tight md:text-5xl">
            Your business.
            <br />
            One financial intelligence platform.
          </h1>
          <p className="mt-6 max-w-md text-lg text-ledger-slate">
            Know what happened. See what&rsquo;s coming. Decide what to do.
          </p>
          <div className="mt-8 flex gap-4">
            <Link
              href="/signup"
              className="rounded-card bg-ink px-6 py-3 text-sm font-medium text-paper hover:bg-ink-700"
            >
              Start free
            </Link>
            <a
              href="#how-it-works"
              className="rounded-card border border-ink-100 px-6 py-3 text-sm font-medium hover:border-ink-400"
            >
              See how it works
            </a>
          </div>
        </div>

        {/* Signature element: live ledger-style health score card */}
        <div className="rounded-card border border-ink-100 bg-paper p-6 shadow-card">
          <div className="flex items-baseline justify-between">
            <span className="font-mono text-xs uppercase tracking-widest text-ledger-slate">
              Business Health Score
            </span>
            <span className="font-mono text-xs text-ledger-sage">↑ 4 vs last month</span>
          </div>
          <div className="mt-2 flex items-end gap-3">
            <span className="font-display text-6xl tabular">82</span>
            <span className="pb-2 font-mono text-sm text-ledger-slate">/ 100</span>
          </div>
          <div className="mt-6 space-y-3 border-t border-ink-100 pt-6">
            <p className="font-mono text-[11px] uppercase tracking-widest text-ledger-slate">
              Needs your attention
            </p>
            {attentionItems.map((item) => (
              <div key={item.text} className="flex items-start gap-3 text-sm">
                <span className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${levelColor[item.level]}`} />
                <span className="text-ink-700">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Three questions, as ledger folios */}
      <section id="how-it-works" className="border-t border-ink-100 bg-paper py-20">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="max-w-lg font-display text-3xl">
            From data to a decision, in three folios.
          </h2>
          <div className="mt-12 grid gap-10 md:grid-cols-3">
            {folios.map((f) => (
              <div key={f.n}>
                <p className="font-mono text-sm text-ledger-gold">{f.n}</p>
                <h3 className="mt-3 font-display text-xl">{f.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-ledger-slate">{f.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AI CFO */}
      <section className="border-t border-ink-100 py-20">
        <div className="mx-auto grid max-w-6xl gap-10 px-6 md:grid-cols-2 md:items-center">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-ledger-gold">AI CFO</p>
            <h2 className="mt-3 font-display text-3xl">Ask it in plain English.</h2>
            <p className="mt-4 text-ledger-slate">
              &ldquo;Why is my cash falling?&rdquo; &ldquo;Which customer owes me the most?&rdquo;
              &ldquo;Can I afford a new machine?&rdquo; Every answer is built from your actual
              records — never invented. If the data isn&rsquo;t there, it says so.
            </p>
          </div>
          <div className="rounded-card border border-ink-100 bg-ink-900 p-6 font-mono text-sm text-paper">
            <p className="text-ledger-slate">You</p>
            <p className="mt-1">Why did profit fall despite higher sales?</p>
            <p className="mt-4 text-ledger-gold">AI CFO</p>
            <p className="mt-1 text-ink-100">
              Finding: Gross margin dropped from 34% to 31.8% this month.
              <br />
              Evidence: COGS rose 9% while revenue rose 6%, driven mainly by raw
              material cost on your top SKU.
              <br />
              Impact: ₹2.1L less gross profit than if margin had held.
              <br />
              Recommendation: Review pricing on that SKU or renegotiate the supplier rate.
            </p>
          </div>
        </div>
      </section>

      {/* Security */}
      <section id="security" className="border-t border-ink-100 bg-paper py-20">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="font-display text-3xl">Built like a financial application, not a dashboard.</h2>
          <div className="mt-10 grid gap-8 text-sm text-ledger-slate md:grid-cols-3">
            <p>Role-based access control across owner, CFO, accountant and viewer roles, with full audit logs.</p>
            <p>Every figure is computed by deterministic financial code — the AI explains numbers, it never invents them.</p>
            <p>AI CFO is decision support, not a licensed advisor, lender or investment adviser. Financing options are illustrative and subject to lender approval.</p>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="border-t border-ink-100 py-20">
        <div className="mx-auto max-w-6xl px-6 text-center">
          <h2 className="font-display text-3xl">Start free. Grow into it.</h2>
          <p className="mx-auto mt-3 max-w-md text-ledger-slate">
            Full demo mode with a populated sample company — no bank or GST credentials required to try it.
          </p>
          <Link
            href="/signup"
            className="mt-8 inline-block rounded-card bg-ink px-8 py-3 text-sm font-medium text-paper hover:bg-ink-700"
          >
            Start free
          </Link>
        </div>
      </section>

      <footer className="border-t border-ink-100 py-8 text-center font-mono text-xs text-ledger-slate">
        AI CFO — financial insights &amp; decision support. Not a bank, NBFC, lender or investment adviser.
      </footer>
    </main>
  );
}
