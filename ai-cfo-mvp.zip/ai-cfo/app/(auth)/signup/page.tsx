"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function SignupPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });
    setLoading(false);
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      setError(body.error ?? "Something went wrong.");
      return;
    }
    router.push("/onboarding");
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-ledger-rule px-6">
      <div className="w-full max-w-sm rounded-card border border-ink-100 bg-paper p-8 shadow-card">
        <Link href="/" className="font-display text-lg italic">AI CFO</Link>
        <h1 className="mt-6 font-display text-2xl">Create your account</h1>
        <p className="mt-1 text-sm text-ledger-slate">Free to start. No card required.</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="text-xs font-medium text-ledger-slate" htmlFor="name">Full name</label>
            <input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              minLength={2}
              className="mt-1 w-full rounded-card border border-ink-100 px-3 py-2 text-sm focus:border-ink-400"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-ledger-slate" htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="mt-1 w-full rounded-card border border-ink-100 px-3 py-2 text-sm focus:border-ink-400"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-ledger-slate" htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={8}
              className="mt-1 w-full rounded-card border border-ink-100 px-3 py-2 text-sm focus:border-ink-400"
            />
            <p className="mt-1 text-xs text-ledger-slate">At least 8 characters.</p>
          </div>
          {error && <p className="text-sm text-ledger-brick">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-card bg-ink py-2.5 text-sm font-medium text-paper hover:bg-ink-700 disabled:opacity-60"
          >
            {loading ? "Creating account…" : "Start free"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-ledger-slate">
          Already have an account? <Link href="/login" className="text-ink hover:underline">Log in</Link>
        </p>
      </div>
    </main>
  );
}
