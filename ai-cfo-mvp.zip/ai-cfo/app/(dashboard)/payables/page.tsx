import { getPayablesTable, getPayablesSummary } from "@/lib/finance/payables";
import { getActiveBusinessId } from "@/lib/auth/current-business";

function formatINR(value: number): string {
  if (Math.abs(value) >= 100000) return `₹${(value / 100000).toFixed(1)}L`;
  return `₹${value.toLocaleString("en-IN")}`;
}

const priorityStyles: Record<string, string> = {
  critical: "bg-ledger-brick/10 text-ledger-brick",
  standard: "bg-ledger-slate/10 text-ledger-slate",
  flexible: "bg-ledger-sage/10 text-ledger-sage",
};

export default async function PayablesPage() {
  const businessId = await getActiveBusinessId();
  const [rows, summary] = await Promise.all([getPayablesTable(businessId), getPayablesSummary(businessId)]);

  if (rows.length === 0) {
    return (
      <div className="rounded-card border border-ink-100 bg-paper p-10 text-center">
        <p className="font-display text-xl">No open payables</p>
        <p className="mt-2 text-sm text-ledger-slate">
          Upload purchase invoices, or connect an integration, to see what you owe and when.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl">Payables</h1>
        <p className="mt-1 text-sm text-ledger-slate">
          {formatINR(summary.totalDue)} due to {summary.supplierCount} suppliers.
        </p>
      </div>

      {summary.deferrableAmount > 0 && (
        <div className="rounded-card border border-ledger-sage/30 bg-ledger-sage/5 p-4 text-sm">
          <p className="font-medium text-ink">
            Up to {formatINR(summary.deferrableAmount)} may have some room to delay slightly
          </p>
          <p className="mt-1 text-ledger-slate">
            Based only on suppliers you&rsquo;ve marked as lower-priority and not yet overdue. This is a
            starting point for your own judgment, not a recommendation to act — never delay statutory
            dues (GST, TDS, PF, ESI) or anything already overdue.
          </p>
        </div>
      )}

      <div className="overflow-x-auto rounded-card border border-ink-100 bg-paper">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-ink-100 font-mono text-[11px] uppercase tracking-widest text-ledger-slate">
              <th className="px-4 py-3">Supplier</th>
              <th className="px-4 py-3">Due date</th>
              <th className="px-4 py-3 text-right">Amount due</th>
              <th className="px-4 py-3">Priority</th>
              <th className="px-4 py-3">Cash impact</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.invoiceId} className="border-b border-ink-100 last:border-0">
                <td className="px-4 py-3">{r.supplierName}</td>
                <td className="px-4 py-3 text-ledger-slate">{r.dueDate.toLocaleDateString("en-IN")}</td>
                <td className="px-4 py-3 text-right tabular">{formatINR(r.amountDue)}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${priorityStyles[r.priority]}`}>
                    {r.priority}
                  </span>
                </td>
                <td className="px-4 py-3 text-ledger-slate capitalize">{r.cashImpact}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
