import { getBusinessHealthSnapshot, getCashTrend } from "@/lib/finance/dashboard-data";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { AlertCard } from "@/components/dashboard/AlertCard";
import { CashTrendChart } from "@/components/charts/CashTrendChart";
import { getActiveBusinessId } from "@/lib/auth/current-business";

function formatINR(value: number): string {
  if (Math.abs(value) >= 100000) return `₹${(value / 100000).toFixed(1)}L`;
  return `₹${value.toLocaleString("en-IN")}`;
}

export default async function DashboardPage() {
  const businessId = await getActiveBusinessId();
  const snapshot = await getBusinessHealthSnapshot(businessId);
  const trend = await getCashTrend(businessId);

  if (!snapshot) {
    return (
      <div className="rounded-card border border-ink-100 bg-paper p-10 text-center">
        <p className="font-display text-xl">No financial data yet</p>
        <p className="mt-2 text-sm text-ledger-slate">
          Upload your sales, purchases and bank statements, or connect an integration, to see your
          Business Health dashboard.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-10">
      <section className="rounded-card border border-ink-100 bg-paper p-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-ledger-slate">
              Business Health Score
            </p>
            <div className="mt-1 flex items-end gap-3">
              <span className="font-display text-5xl tabular">{snapshot.healthScore}</span>
              <span className="pb-1 font-mono text-sm text-ledger-slate">/ 100</span>
              {snapshot.healthScoreDelta !== 0 && (
                <span
                  className={`pb-1 font-mono text-sm ${
                    snapshot.healthScoreDelta > 0 ? "text-ledger-sage" : "text-ledger-brick"
                  }`}
                >
                  {snapshot.healthScoreDelta > 0 ? "↑" : "↓"} {Math.abs(snapshot.healthScoreDelta)} vs last period
                </span>
              )}
            </div>
          </div>
          <div className="w-full max-w-md">
            <CashTrendChart data={trend} />
          </div>
        </div>
      </section>

      <section className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <MetricCard label="Revenue" value={formatINR(snapshot.revenue)} />
        <MetricCard label="Gross margin" value={`${snapshot.grossMargin}%`} />
        <MetricCard label="EBITDA" value={formatINR(snapshot.ebitda)} />
        <MetricCard label="Cash balance" value={formatINR(snapshot.cashBalance)} />
        <MetricCard label="Receivables" value={formatINR(snapshot.receivables)} />
        <MetricCard label="Payables" value={formatINR(snapshot.payables)} />
        <MetricCard label="Inventory" value={formatINR(snapshot.inventoryValue)} />
        <MetricCard label="Debt" value={formatINR(snapshot.debtOutstanding)} />
        <MetricCard
          label="Working capital"
          value={formatINR(snapshot.workingCapital)}
          tone={snapshot.workingCapital >= 0 ? "positive" : "negative"}
        />
        <MetricCard
          label="Cash conversion cycle"
          value={`${snapshot.cashConversionCycleDays} days`}
          sublabel="Lower means cash comes back faster"
        />
      </section>

      <section>
        <h2 className="font-display text-xl">What needs your attention</h2>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {snapshot.insights.length === 0 && (
            <p className="text-sm text-ledger-slate">Nothing urgent right now — you&rsquo;re in good shape.</p>
          )}
          {snapshot.insights.map((i) => (
            <AlertCard key={i.id} id={i.id} title={i.title} reason={i.reason} severity={i.severity} />
          ))}
        </div>
      </section>
    </div>
  );
}
