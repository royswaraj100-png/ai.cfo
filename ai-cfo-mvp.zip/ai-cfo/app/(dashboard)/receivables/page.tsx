import { getReceivablesTable, getAgingSummary, getCustomerReceivableProfiles } from "@/lib/finance/receivables";
import { getActiveBusinessId } from "@/lib/auth/current-business";
import { AgingBarChart } from "@/components/charts/AgingBarChart";
import { RiskBadge } from "@/components/dashboard/RiskBadge";

function formatINR(value: number): string {
  if (Math.abs(value) >= 100000) return `₹${(value / 100000).toFixed(1)}L`;
  return `₹${value.toLocaleString("en-IN")}`;
}

export default async function ReceivablesPage() {
  const businessId = await getActiveBusinessId();
  const [rows, aging, profiles] = await Promise.all([
    getReceivablesTable(businessId),
    getAgingSummary(businessId),
    getCustomerReceivableProfiles(businessId),
  ]);

  const agingData = Object.entries(aging).map(([bucket, amount]) => ({ bucket, amount }));
  const totalOutstanding = agingData.reduce((s, d) => s + d.amount, 0);

  if (rows.length === 0) {
    return (
      <div className="rounded-card border border-ink-100 bg-paper p-10 text-center">
        <p className="font-display text-xl">No open receivables</p>
        <p className="mt-2 text-sm text-ledger-slate">
          Upload sales invoices, or connect an integration, to see who owes you money and when.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-10">
      <div>
        <h1 className="font-display text-2xl">Receivables</h1>
        <p className="mt-1 text-sm text-ledger-slate">
          {formatINR(totalOutstanding)} outstanding across {rows.length} open invoices.
        </p>
      </div>

      <section className="rounded-card border border-ink-100 bg-paper p-6">
        <p className="font-mono text-[11px] uppercase tracking-widest text-ledger-slate">Aging summary</p>
        <div className="mt-2">
          <AgingBarChart data={agingData} />
        </div>
      </section>

      <section>
        <h2 className="font-display text-xl">Customer payment behaviour</h2>
        <div className="mt-4 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {profiles
            .filter((p) => p.outstanding > 0)
            .map((p) => (
              <div key={p.customerId} className="rounded-card border border-ink-100 bg-paper p-4">
                <div className="flex items-start justify-between">
                  <p className="font-medium text-ink">{p.customerName}</p>
                  <RiskBadge level={p.riskLevel} />
                </div>
                <p className="mt-2 font-display text-xl tabular">{formatINR(p.outstanding)}</p>
                <p className="text-xs text-ledger-slate">outstanding</p>
                <div className="mt-3 flex justify-between text-xs text-ledger-slate">
                  <span>Avg. delay: {p.avgPaymentDelayDays} days</span>
                  <span>Reliability: {p.paymentReliabilityPct}%</span>
                </div>
              </div>
            ))}
        </div>
      </section>

      <section>
        <h2 className="font-display text-xl">Open invoices</h2>
        <div className="mt-4 overflow-x-auto rounded-card border border-ink-100 bg-paper">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-ink-100 font-mono text-[11px] uppercase tracking-widest text-ledger-slate">
                <th className="px-4 py-3">Customer</th>
                <th className="px-4 py-3">Invoice</th>
                <th className="px-4 py-3">Due date</th>
                <th className="px-4 py-3 text-right">Outstanding</th>
                <th className="px-4 py-3 text-right">Days</th>
                <th className="px-4 py-3">Risk</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.invoiceId} className="border-b border-ink-100 last:border-0">
                  <td className="px-4 py-3">{r.customerName}</td>
                  <td className="px-4 py-3 font-mono text-xs">{r.invoiceNumber}</td>
                  <td className="px-4 py-3 text-ledger-slate">{r.dueDate.toLocaleDateString("en-IN")}</td>
                  <td className="px-4 py-3 text-right tabular">{formatINR(r.outstanding)}</td>
                  <td className="px-4 py-3 text-right tabular text-ledger-slate">
                    {r.daysOutstanding > 0 ? r.daysOutstanding : "—"}
                  </td>
                  <td className="px-4 py-3">
                    <RiskBadge level={r.riskLevel} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
