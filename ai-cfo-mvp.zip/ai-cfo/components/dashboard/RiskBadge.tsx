const styles: Record<string, string> = {
  Low: "bg-ledger-sage/10 text-ledger-sage",
  Medium: "bg-ledger-gold/10 text-ledger-gold",
  High: "bg-ledger-brick/10 text-ledger-brick",
};

export function RiskBadge({ level }: { level: "Low" | "Medium" | "High" }) {
  return (
    <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${styles[level]}`}>{level}</span>
  );
}
