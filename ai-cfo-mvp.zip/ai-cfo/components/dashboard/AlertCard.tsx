import Link from "next/link";

const severityStyles: Record<string, { dot: string; label: string }> = {
  CRITICAL: { dot: "bg-ledger-brick", label: "Critical" },
  WARNING: { dot: "bg-ledger-gold", label: "Needs attention" },
  INFO: { dot: "bg-ledger-slate", label: "Worth noting" },
};

export function AlertCard({
  id,
  title,
  reason,
  severity,
}: {
  id: string;
  title: string;
  reason: string;
  severity: "CRITICAL" | "WARNING" | "INFO";
}) {
  const style = severityStyles[severity];
  return (
    <Link
      href={`/insights/${id}`}
      className="flex items-start gap-3 rounded-card border border-ink-100 bg-paper p-4 transition hover:border-ink-400"
    >
      <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${style.dot}`} />
      <div>
        <p className="text-sm font-medium text-ink">{title}</p>
        <p className="mt-1 text-xs text-ledger-slate">{reason}</p>
      </div>
    </Link>
  );
}
