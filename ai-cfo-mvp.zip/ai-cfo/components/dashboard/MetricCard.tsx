export function MetricCard({
  label,
  value,
  sublabel,
  tone = "neutral",
}: {
  label: string;
  value: string;
  sublabel?: string;
  tone?: "neutral" | "positive" | "negative";
}) {
  const toneClass =
    tone === "positive" ? "text-ledger-sage" : tone === "negative" ? "text-ledger-brick" : "text-ink-700";

  return (
    <div className="rounded-card border border-ink-100 bg-paper p-5">
      <p className="font-mono text-[11px] uppercase tracking-widest text-ledger-slate">{label}</p>
      <p className="mt-2 font-display text-2xl tabular text-ink">{value}</p>
      {sublabel && <p className={`mt-1 text-xs ${toneClass}`}>{sublabel}</p>}
    </div>
  );
}
