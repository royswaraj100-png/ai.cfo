"use client";

import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

export function CashTrendChart({ data }: { data: { month: string; cash: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={220}>
      <AreaChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id="cashFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#B8863B" stopOpacity={0.25} />
            <stop offset="100%" stopColor="#B8863B" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid vertical={false} stroke="#E4E7EC" />
        <XAxis dataKey="month" tick={{ fontSize: 12, fill: "#6B7785" }} axisLine={false} tickLine={false} />
        <YAxis
          tick={{ fontSize: 12, fill: "#6B7785" }}
          axisLine={false}
          tickLine={false}
          tickFormatter={(v) => `₹${(v / 100000).toFixed(0)}L`}
        />
        <Tooltip
          formatter={(value: number) => [`₹${value.toLocaleString("en-IN")}`, "Cash balance"]}
          contentStyle={{ borderRadius: 8, borderColor: "#E4E7EC", fontSize: 13 }}
        />
        <Area type="monotone" dataKey="cash" stroke="#B8863B" strokeWidth={2} fill="url(#cashFill)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}
