"use client";

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from "recharts";

const bucketColors: Record<string, string> = {
  current: "#3F6357",
  "1-30": "#B8863B",
  "31-60": "#C79A56",
  "61-90": "#A2603E",
  "90+": "#A23E2C",
};

export function AgingBarChart({ data }: { data: { bucket: string; amount: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
        <CartesianGrid vertical={false} stroke="#E4E7EC" />
        <XAxis dataKey="bucket" tick={{ fontSize: 12, fill: "#6B7785" }} axisLine={false} tickLine={false} />
        <YAxis
          tick={{ fontSize: 12, fill: "#6B7785" }}
          axisLine={false}
          tickLine={false}
          tickFormatter={(v) => `₹${(v / 100000).toFixed(0)}L`}
        />
        <Tooltip
          formatter={(value: number) => [`₹${value.toLocaleString("en-IN")}`, "Outstanding"]}
          contentStyle={{ borderRadius: 8, borderColor: "#E4E7EC", fontSize: 13 }}
        />
        <Bar dataKey="amount" radius={[4, 4, 0, 0]}>
          {data.map((d) => (
            <Cell key={d.bucket} fill={bucketColors[d.bucket] ?? "#6B7785"} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
