import type { AIProvider, ChatMessage, ToolDefinition, CompletionResult } from "../provider";

const API_URL = "https://api.anthropic.com/v1/messages";
const MODEL = process.env.ANTHROPIC_MODEL ?? "claude-sonnet-4-6";

function toAnthropicMessages(messages: ChatMessage[]) {
  return messages
    .filter((m) => m.role !== "system")
    .map((m) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: m.content,
    }));
}

export const anthropicProvider: AIProvider = {
  async complete({ messages, tools, maxTokens = 1024 }) {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      throw new Error("ANTHROPIC_API_KEY is not set. Never hardcode this — use environment variables.");
    }

    const system = messages.find((m) => m.role === "system")?.content;

    const body: Record<string, unknown> = {
      model: MODEL,
      max_tokens: maxTokens,
      system,
      messages: toAnthropicMessages(messages),
    };

    if (tools && tools.length > 0) {
      body.tools = tools.map((t) => ({
        name: t.name,
        description: t.description,
        input_schema: t.parameters,
      }));
    }

    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Anthropic API error (${response.status}): ${errText}`);
    }

    const data = await response.json();

    const result: CompletionResult = { text: null, toolCalls: [] };
    for (const block of data.content ?? []) {
      if (block.type === "text") {
        result.text = (result.text ?? "") + block.text;
      } else if (block.type === "tool_use") {
        result.toolCalls.push({ id: block.id, name: block.name, arguments: block.input });
      }
    }
    return result;
  },
};
