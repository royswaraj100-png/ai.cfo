/**
 * LLM Provider Abstraction
 * ------------------------
 * The rest of the app (lib/ai/cfo-agent.ts, API routes) talks to this
 * interface only. Swapping providers means writing one new adapter file
 * here — nothing else in the codebase changes.
 */

export interface ChatMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  toolCallId?: string;
  toolName?: string;
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, unknown>; // JSON schema
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
}

export interface CompletionResult {
  text: string | null;
  toolCalls: ToolCall[];
}

export interface AIProvider {
  complete(params: {
    messages: ChatMessage[];
    tools?: ToolDefinition[];
    maxTokens?: number;
  }): Promise<CompletionResult>;
}

/**
 * Reads which provider to use from env at call time (not build time), so an
 * ops team can switch providers via configuration alone.
 */
export function getAIProvider(): AIProvider {
  const providerName = process.env.AI_PROVIDER ?? "anthropic";

  switch (providerName) {
    case "anthropic":
      // Lazy import so unused adapters never need their SDK installed.
      return require("./providers/anthropic-provider").anthropicProvider;
    case "openai":
      return require("./providers/openai-provider").openAIProvider;
    default:
      throw new Error(`Unknown AI_PROVIDER: ${providerName}`);
  }
}
