/**
 * AI CFO — Financial Tools
 * ------------------------
 * The LLM never queries the database directly and never computes a
 * financial figure itself. It can only call these named, typed functions.
 * Each function:
 *   1. Reads real rows from Postgres via Prisma
 *   2. Runs them through the deterministic engine in lib/finance/calculations.ts
 *   3. Returns a plain JSON result the model is instructed to report faithfully
 *
 * If a tool has no data to work with, it returns { available: false } and the
 * agent is instructed (see cfo-agent.ts system prompt) to say so rather than guess.
 */

import { prisma } from "../db/client";
import * as calc from "../finance/calculations";
import type { ToolDefinition } from "./provider";

export const financialToolDefinitions: ToolDefinition[] = [
  {
    name: "getRevenue",
    description: "Get total revenue for the business over a date range, with comparison to the prior period of equal length.",
    parameters: {
      type: "object",
      properties: {
        startDate: { type: "string", description: "ISO date, inclusive" },
        endDate: { type: "string", description: "ISO date, inclusive" },
      },
      required: ["startDate", "endDate"],
    },
  },
  {
    name: "getCashBalance",
    description: "Get the business's current cash balance as of the latest bank transaction on record.",
    parameters: { type: "object", properties: {} },
  },
  {
    name: "getReceivables",
    description: "Get outstanding receivables, aged into current/1-30/31-60/61-90/90+ buckets, optionally filtered to one customer.",
    parameters: {
      type: "object",
      properties: {
        customerName: { type: "string", description: "Optional. Filter to a specific customer by name." },
      },
    },
  },
  {
    name: "getPayables",
    description: "Get outstanding payables to suppliers, with due dates and supplier priority.",
    parameters: { type: "object", properties: {} },
  },
  {
    name: "getCustomerProfitability",
    description: "Get revenue, COGS, and gross margin broken down by customer, ranked most to least profitable.",
    parameters: {
      type: "object",
      properties: {
        startDate: { type: "string" },
        endDate: { type: "string" },
      },
      required: ["startDate", "endDate"],
    },
  },
  {
    name: "getCashForecast",
    description: "Get the cash flow forecast (base, optimistic, or stress case) for the next 30 or 90 days.",
    parameters: {
      type: "object",
      properties: {
        horizonDays: { type: "number", enum: [30, 90] },
        scenario: { type: "string", enum: ["BASE", "OPTIMISTIC", "STRESS"] },
      },
      required: ["horizonDays"],
    },
  },
  {
    name: "getWorkingCapital",
    description: "Get current working capital, the cash conversion cycle, and the estimated funding gap if any.",
    parameters: { type: "object", properties: {} },
  },
  {
    name: "getFinancialRisks",
    description: "Get the current list of active AI-generated risk insights and alerts for the business, ranked by severity.",
    parameters: { type: "object", properties: {} },
  },
];

type ToolResult = Record<string, unknown>;

export async function callFinancialTool(
  businessId: string,
  toolName: string,
  args: Record<string, unknown>
): Promise<ToolResult> {
  switch (toolName) {
    case "getRevenue":
      return getRevenue(businessId, args.startDate as string, args.endDate as string);
    case "getCashBalance":
      return getCashBalance(businessId);
    case "getReceivables":
      return getReceivables(businessId, args.customerName as string | undefined);
    case "getPayables":
      return getPayables(businessId);
    case "getCustomerProfitability":
      return getCustomerProfitability(businessId, args.startDate as string, args.endDate as string);
    case "getCashForecast":
      return getCashForecast(businessId, args.horizonDays as number, (args.scenario as string) ?? "BASE");
    case "getWorkingCapital":
      return getWorkingCapital(businessId);
    case "getFinancialRisks":
      return getFinancialRisks(businessId);
    default:
      return { available: false, reason: `Unknown tool: ${toolName}` };
  }
}

// ---------------------------------------------------------------------------

async function getRevenue(businessId: string, startDate: string, endDate: string): Promise<ToolResult> {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const items = await prisma.invoiceItem.findMany({
    where: { invoice: { businessId, type: "SALES", invoiceDate: { gte: start, lte: end } } },
    select: { quantity: true, unitPrice: true, unitCost: true },
  });
  if (items.length === 0) return { available: false };

  const lines = items.map((i) => ({
    quantity: Number(i.quantity),
    unitPrice: Number(i.unitPrice),
    unitCost: Number(i.unitCost),
  }));

  return {
    available: true,
    periodStart: startDate,
    periodEnd: endDate,
    revenue: calc.revenue(lines),
    cogs: calc.cogs(lines),
    grossProfit: calc.grossProfit(calc.revenue(lines), calc.cogs(lines)),
    grossMarginPct: calc.grossMarginPct(calc.revenue(lines), calc.cogs(lines)),
  };
}

async function getCashBalance(businessId: string): Promise<ToolResult> {
  const latest = await prisma.bankTransaction.findFirst({
    where: { businessId },
    orderBy: { txnDate: "desc" },
  });
  if (!latest || latest.balanceAfter === null) return { available: false };
  return {
    available: true,
    cashBalance: Number(latest.balanceAfter),
    asOf: latest.txnDate.toISOString(),
  };
}

async function getReceivables(businessId: string, customerName?: string): Promise<ToolResult> {
  const invoices = await prisma.invoice.findMany({
    where: {
      businessId,
      type: "SALES",
      status: { in: ["OPEN", "PARTIALLY_PAID", "OVERDUE"] },
      ...(customerName ? { customer: { name: { contains: customerName, mode: "insensitive" } } } : {}),
    },
    include: { customer: true },
  });
  if (invoices.length === 0) return { available: false };

  const asOf = new Date();
  const schedule = calc.agingSchedule(
    invoices.map((i) => ({ amount: Number(i.amount), amountPaid: Number(i.amountPaid), dueDate: i.dueDate })),
    asOf
  );
  const totalOutstanding = Object.values(schedule).reduce((a, b) => a + b, 0);

  return {
    available: true,
    asOf: asOf.toISOString(),
    totalOutstanding: Math.round(totalOutstanding * 100) / 100,
    agingSchedule: schedule,
    invoiceCount: invoices.length,
    filteredToCustomer: customerName ?? null,
  };
}

async function getPayables(businessId: string): Promise<ToolResult> {
  const invoices = await prisma.invoice.findMany({
    where: { businessId, type: "PURCHASE", status: { in: ["OPEN", "PARTIALLY_PAID", "OVERDUE"] } },
    include: { supplier: true },
    orderBy: { dueDate: "asc" },
  });
  if (invoices.length === 0) return { available: false };

  const totalOutstanding = invoices.reduce((s, i) => s + (Number(i.amount) - Number(i.amountPaid)), 0);

  return {
    available: true,
    totalOutstanding: Math.round(totalOutstanding * 100) / 100,
    items: invoices.map((i) => ({
      supplier: i.supplier?.name ?? "Unknown",
      priority: i.supplier?.priority ?? "standard",
      amountDue: Number(i.amount) - Number(i.amountPaid),
      dueDate: i.dueDate.toISOString(),
    })),
  };
}

async function getCustomerProfitability(businessId: string, startDate: string, endDate: string): Promise<ToolResult> {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const invoices = await prisma.invoice.findMany({
    where: { businessId, type: "SALES", invoiceDate: { gte: start, lte: end } },
    include: { customer: true, items: true },
  });
  if (invoices.length === 0) return { available: false };

  const byCustomer = new Map<string, { revenue: number; cogsValue: number }>();
  for (const inv of invoices) {
    const name = inv.customer?.name ?? "Unknown";
    const lines = inv.items.map((it) => ({
      quantity: Number(it.quantity),
      unitPrice: Number(it.unitPrice),
      unitCost: Number(it.unitCost),
    }));
    const entry = byCustomer.get(name) ?? { revenue: 0, cogsValue: 0 };
    entry.revenue += calc.revenue(lines);
    entry.cogsValue += calc.cogs(lines);
    byCustomer.set(name, entry);
  }

  const ranked = Array.from(byCustomer.entries())
    .map(([customer, v]) => ({
      customer,
      revenue: Math.round(v.revenue * 100) / 100,
      grossProfit: calc.grossProfit(v.revenue, v.cogsValue),
      grossMarginPct: calc.grossMarginPct(v.revenue, v.cogsValue),
    }))
    .sort((a, b) => b.grossProfit - a.grossProfit);

  return { available: true, periodStart: startDate, periodEnd: endDate, customers: ranked };
}

async function getCashForecast(businessId: string, horizonDays: number, scenario: string): Promise<ToolResult> {
  const forecasts = await prisma.cashFlowForecast.findMany({
    where: { businessId, scenario: scenario as any },
    orderBy: { forecastDate: "asc" },
    take: horizonDays,
  });
  if (forecasts.length === 0) return { available: false };

  const last = forecasts[forecasts.length - 1];
  const criticalPoint = forecasts.find((f) => Number(f.closingCash) < 0);

  return {
    available: true,
    scenario,
    horizonDays,
    openingCash: Number(forecasts[0].openingCash),
    projectedClosingCash: Number(last.closingCash),
    cashBecomesNegativeOn: criticalPoint ? criticalPoint.forecastDate.toISOString() : null,
    dailySeries: forecasts.map((f) => ({
      date: f.forecastDate.toISOString(),
      closingCash: Number(f.closingCash),
    })),
  };
}

async function getWorkingCapital(businessId: string): Promise<ToolResult> {
  const metric = await prisma.financialMetric.findFirst({
    where: { businessId },
    orderBy: { periodEnd: "desc" },
  });
  if (!metric) return { available: false };

  const availableCash = Number(metric.cashBalance);
  const required = calc.requiredWorkingCapital(
    Number(metric.cashConversionCycleDays),
    Number(metric.cogs) / 90 // approx daily outflow over the reporting period
  );

  return {
    available: true,
    asOfPeriodEnd: metric.periodEnd.toISOString(),
    currentWorkingCapital: Number(metric.workingCapital),
    cashConversionCycleDays: Number(metric.cashConversionCycleDays),
    requiredWorkingCapital: required,
    availableCash,
    fundingGap: calc.fundingGap(required, availableCash),
  };
}

async function getFinancialRisks(businessId: string): Promise<ToolResult> {
  const insights = await prisma.insight.findMany({
    where: { businessId },
    orderBy: [{ severity: "desc" }, { createdAt: "desc" }],
    take: 10,
  });
  if (insights.length === 0) return { available: false };

  return {
    available: true,
    risks: insights.map((i) => ({
      title: i.title,
      severity: i.severity,
      finding: i.finding,
      reason: i.reason,
      impact: i.impact,
      recommendation: i.recommendation,
    })),
  };
}
