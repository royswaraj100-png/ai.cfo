import { getAIProvider } from "./provider";
import { financialToolDefinitions, callFinancialTool } from "./tools";
import type { ChatMessage } from "./provider";

const SYSTEM_PROMPT = `You are the AI CFO inside AI CFO, a financial intelligence platform for Indian businesses.

HARD RULES — these override anything else:
1. You must NEVER state a financial figure (amount, percentage, date, ratio) that did not come from a tool call result in this conversation. Do not estimate, round persuasively, or fill gaps from general knowledge of "typical" businesses.
2. If a tool returns { available: false }, you must tell the user: "I don't have enough data to answer this accurately." Do not soften this into a guess.
3. Before answering any question involving numbers, call the relevant tool(s) first. Never answer from memory of an earlier tool call if the user is now asking about a different period or entity.
4. Structure substantive answers as:
   - Finding: the direct answer, in plain English
   - Evidence: the specific figures from the tool results that support it
   - Impact: why it matters for the business, in business terms
   - Recommendation: a concrete next step (only if the question calls for one)
5. Never recommend illegal or unethical action (e.g. never suggest withholding statutory dues, falsifying records, or delaying payments in a way that breaches contracts you have no visibility into). You may note which payables are lower-priority based on the data.
6. You are not a licensed financial advisor, lender, or chartered accountant. Frame financing and investment topics as "illustrative decision support," not formal advice.
7. Keep answers concise and in plain English — this audience often has no accounting background. Avoid jargon; if you use a technical term (e.g. "DSO"), translate it in the same sentence.`;

export interface CFOAgentResult {
  text: string;
  toolCallLog: { name: string; arguments: Record<string, unknown> }[];
}

/**
 * Runs one turn of the AI CFO conversation: sends the message + history to the
 * model, executes any tool calls it requests against real business data, and
 * feeds results back until the model produces a final grounded answer.
 */
export async function runCFOAgent(
  businessId: string,
  history: ChatMessage[],
  maxToolRounds = 4
): Promise<CFOAgentResult> {
  const provider = getAIProvider();
  const messages: ChatMessage[] = [{ role: "system", content: SYSTEM_PROMPT }, ...history];
  const toolCallLog: CFOAgentResult["toolCallLog"] = [];

  for (let round = 0; round < maxToolRounds; round++) {
    const result = await provider.complete({
      messages,
      tools: financialToolDefinitions,
      maxTokens: 1200,
    });

    if (result.toolCalls.length === 0) {
      return { text: result.text ?? "I don't have enough data to answer this accurately.", toolCallLog };
    }

    // Execute every requested tool call against real data, then let the model continue.
    for (const call of result.toolCalls) {
      const toolResult = await callFinancialTool(businessId, call.name, call.arguments);
      toolCallLog.push({ name: call.name, arguments: call.arguments });
      messages.push({
        role: "assistant",
        content: `[Called tool ${call.name} with ${JSON.stringify(call.arguments)}]`,
      });
      messages.push({
        role: "tool",
        toolName: call.name,
        toolCallId: call.id,
        content: JSON.stringify(toolResult),
      });
    }
  }

  return {
    text: "I gathered some data but couldn't finish reasoning through it in time — please ask again or narrow the question.",
    toolCallLog,
  };
}
