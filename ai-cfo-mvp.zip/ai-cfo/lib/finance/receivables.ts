import { prisma } from "../db/client";
import * as calc from "./calculations";
import type { AgingBucket } from "./calculations";

export interface ReceivableRow {
  invoiceId: string;
  customerName: string;
  invoiceNumber: string;
  invoiceDate: Date;
  dueDate: Date;
  amount: number;
  outstanding: number;
  daysOutstanding: number;
  bucket: AgingBucket;
  riskLevel: "Low" | "Medium" | "High";
}

export interface CustomerReceivableProfile {
  customerId: string;
  customerName: string;
  outstanding: number;
  avgPaymentDelayDays: number;
  paymentReliabilityPct: number;
  riskLevel: "Low" | "Medium" | "High";
  invoiceCount: number;
}

function riskFromSignals(avgDelay: number, reliability: number): "Low" | "Medium" | "High" {
  if (reliability >= 90 && avgDelay <= 10) return "Low";
  if (reliability >= 70 && avgDelay <= 30) return "Medium";
  return "High";
}

export async function getReceivablesTable(businessId: string): Promise<ReceivableRow[]> {
  const asOf = new Date();
  const invoices = await prisma.invoice.findMany({
    where: { businessId, type: "SALES", status: { in: ["OPEN", "PARTIALLY_PAID", "OVERDUE"] } },
    include: { customer: true },
    orderBy: { dueDate: "asc" },
  });

  // Precompute each customer's historical reliability/delay to assign per-invoice risk.
  const profiles = await getCustomerReceivableProfiles(businessId);
  const profileByCustomer = new Map(profiles.map((p) => [p.customerId, p]));

  return invoices
    .map((inv) => {
      const outstanding = Number(inv.amount) - Number(inv.amountPaid);
      if (outstanding <= 0) return null;
      const daysOutstanding = Math.max(
        0,
        Math.floor((asOf.getTime() - inv.dueDate.getTime()) / 86_400_000)
      );
      const profile = inv.customerId ? profileByCustomer.get(inv.customerId) : undefined;
      return {
        invoiceId: inv.id,
        customerName: inv.customer?.name ?? "Unknown",
        invoiceNumber: inv.number,
        invoiceDate: inv.invoiceDate,
        dueDate: inv.dueDate,
        amount: Number(inv.amount),
        outstanding: Math.round(outstanding * 100) / 100,
        daysOutstanding,
        bucket: calc.agingBucket(inv.dueDate, asOf),
        riskLevel: profile?.riskLevel ?? "Medium",
      };
    })
    .filter((r): r is ReceivableRow => r !== null);
}

export async function getAgingSummary(businessId: string) {
  const invoices = await prisma.invoice.findMany({
    where: { businessId, type: "SALES", status: { in: ["OPEN", "PARTIALLY_PAID", "OVERDUE"] } },
    select: { amount: true, amountPaid: true, dueDate: true },
  });
  return calc.agingSchedule(
    invoices.map((i) => ({ amount: Number(i.amount), amountPaid: Number(i.amountPaid), dueDate: i.dueDate })),
    new Date()
  );
}

export async function getCustomerReceivableProfiles(businessId: string): Promise<CustomerReceivableProfile[]> {
  const customers = await prisma.customer.findMany({
    where: { businessId },
    include: { invoices: { include: { payments: true } } },
  });

  return customers
    .map((customer) => {
      const paidInvoices = customer.invoices.filter((i) => i.status === "PAID" && i.payments.length > 0);
      const delays: number[] = [];
      let onTimeCount = 0;

      for (const inv of paidInvoices) {
        const lastPayment = inv.payments.reduce((latest, p) => (p.paidOn > latest.paidOn ? p : latest));
        const delayDays = Math.floor((lastPayment.paidOn.getTime() - inv.dueDate.getTime()) / 86_400_000);
        delays.push(Math.max(0, delayDays));
        if (delayDays <= 0) onTimeCount++;
      }

      const avgDelay = calc.avgPaymentDelayDays(delays);
      const reliability = calc.paymentReliability(onTimeCount, paidInvoices.length);
      const outstanding = customer.invoices
        .filter((i) => i.status !== "PAID" && i.status !== "CANCELLED")
        .reduce((sum, i) => sum + (Number(i.amount) - Number(i.amountPaid)), 0);

      return {
        customerId: customer.id,
        customerName: customer.name,
        outstanding: Math.round(outstanding * 100) / 100,
        avgPaymentDelayDays: avgDelay,
        paymentReliabilityPct: reliability,
        riskLevel: riskFromSignals(avgDelay, reliability),
        invoiceCount: customer.invoices.length,
      };
    })
    .filter((p) => p.outstanding > 0 || p.invoiceCount > 0)
    .sort((a, b) => b.outstanding - a.outstanding);
}
