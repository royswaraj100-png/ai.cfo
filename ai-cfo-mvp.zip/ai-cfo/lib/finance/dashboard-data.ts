import { prisma } from "../db/client";

export async function getBusinessHealthSnapshot(businessId: string) {
  const [latest, previous, insights] = await Promise.all([
    prisma.financialMetric.findFirst({ where: { businessId }, orderBy: { periodEnd: "desc" } }),
    prisma.financialMetric.findMany({ where: { businessId }, orderBy: { periodEnd: "desc" }, skip: 1, take: 1 }),
    prisma.insight.findMany({
      where: { businessId, isRead: false },
      orderBy: [{ severity: "desc" }, { createdAt: "desc" }],
      take: 8,
    }),
  ]);

  if (!latest) return null;

  const prev = previous[0] ?? null;

  return {
    healthScore: latest.healthScore,
    healthScoreDelta: prev ? latest.healthScore - prev.healthScore : 0,
    revenue: Number(latest.revenue),
    grossMargin: Number(latest.grossMargin),
    ebitda: Number(latest.ebitda),
    cashBalance: Number(latest.cashBalance),
    receivables: Number(latest.receivables),
    payables: Number(latest.payables),
    inventoryValue: Number(latest.inventoryValue),
    debtOutstanding: Number(latest.debtOutstanding),
    workingCapital: Number(latest.workingCapital),
    cashConversionCycleDays: Number(latest.cashConversionCycleDays),
    periodEnd: latest.periodEnd,
    insights,
  };
}

export async function getCashTrend(businessId: string, months = 12) {
  const rows = await prisma.financialMetric.findMany({
    where: { businessId },
    orderBy: { periodEnd: "asc" },
    take: months,
  });
  return rows.map((r) => ({
    month: r.periodEnd.toLocaleDateString("en-IN", { month: "short" }),
    cash: Number(r.cashBalance),
  }));
}
