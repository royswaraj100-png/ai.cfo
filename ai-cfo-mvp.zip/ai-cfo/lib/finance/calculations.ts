/**
 * Deterministic Financial Calculation Engine
 * ------------------------------------------
 * Every number shown anywhere in AI CFO — dashboard, forecasts, AI answers —
 * is produced by this module (or the modules it composes with). The LLM is
 * NEVER allowed to compute or invent a financial figure; it only reads the
 * output of these functions through the tool layer in `lib/ai/tools.ts`.
 *
 * All money values are plain numbers in INR (rupees), not paise, unless noted.
 */

export interface Invoice {
  id: string;
  type: "SALES" | "PURCHASE";
  amount: number;
  amountPaid: number;
  invoiceDate: Date;
  dueDate: Date;
  status: string;
}

export interface CostedLine {
  quantity: number;
  unitPrice: number;
  unitCost: number;
}

// ---------------------------------------------------------------------------
// P&L basics
// ---------------------------------------------------------------------------

export function revenue(salesLines: CostedLine[]): number {
  return round2(salesLines.reduce((sum, l) => sum + l.quantity * l.unitPrice, 0));
}

export function cogs(salesLines: CostedLine[]): number {
  return round2(salesLines.reduce((sum, l) => sum + l.quantity * l.unitCost, 0));
}

export function grossProfit(rev: number, cogsValue: number): number {
  return round2(rev - cogsValue);
}

export function grossMarginPct(rev: number, cogsValue: number): number {
  if (rev === 0) return 0;
  return round2(((rev - cogsValue) / rev) * 100);
}

export function ebitda(grossProfitValue: number, operatingExpenses: number): number {
  return round2(grossProfitValue - operatingExpenses);
}

// ---------------------------------------------------------------------------
// Liquidity & working capital
// ---------------------------------------------------------------------------

export function currentRatio(currentAssets: number, currentLiabilities: number): number {
  if (currentLiabilities === 0) return currentAssets > 0 ? Infinity : 0;
  return round2(currentAssets / currentLiabilities);
}

/** Days Sales Outstanding: how long, on average, it takes customers to pay. */
export function receivableDays(avgReceivables: number, rev: number, periodDays: number): number {
  if (rev === 0) return 0;
  return round1((avgReceivables / rev) * periodDays);
}

/** Days Payable Outstanding: how long, on average, we take to pay suppliers. */
export function payableDays(avgPayables: number, cogsValue: number, periodDays: number): number {
  if (cogsValue === 0) return 0;
  return round1((avgPayables / cogsValue) * periodDays);
}

/** Days Inventory Outstanding: how long inventory sits before it's sold. */
export function inventoryDays(avgInventory: number, cogsValue: number, periodDays: number): number {
  if (cogsValue === 0) return 0;
  return round1((avgInventory / cogsValue) * periodDays);
}

/** Cash Conversion Cycle = DIO + DSO - DPO. Lower is better (less cash tied up). */
export function cashConversionCycle(dio: number, dso: number, dpo: number): number {
  return round1(dio + dso - dpo);
}

export function workingCapital(currentAssets: number, currentLiabilities: number): number {
  return round2(currentAssets - currentLiabilities);
}

/**
 * Estimate required working capital from the cash conversion cycle and the
 * average daily cash outflow (COGS + opex per day). This is a standard
 * approximation used for financing-need sizing, not an exact treasury model.
 */
export function requiredWorkingCapital(
  cashConversionCycleDays: number,
  avgDailyCashOutflow: number
): number {
  return round2(Math.max(0, cashConversionCycleDays) * avgDailyCashOutflow);
}

export function fundingGap(requiredWC: number, availableCash: number): number {
  return round2(Math.max(0, requiredWC - availableCash));
}

// ---------------------------------------------------------------------------
// Debt & cash runway
// ---------------------------------------------------------------------------

export function debtServiceCoverageRatio(ebitdaValue: number, annualDebtService: number): number {
  if (annualDebtService === 0) return Infinity;
  return round2(ebitdaValue / annualDebtService);
}

/** Average net cash burn per day over a lookback window (negative = burning cash). */
export function cashBurnPerDay(netCashChange: number, periodDays: number): number {
  if (periodDays === 0) return 0;
  return round2(netCashChange / periodDays);
}

/** Days of runway left at the current burn rate. Returns null if not burning cash. */
export function cashRunwayDays(currentCash: number, burnPerDay: number): number | null {
  if (burnPerDay >= 0) return null;
  return Math.floor(currentCash / Math.abs(burnPerDay));
}

// ---------------------------------------------------------------------------
// Receivables aging
// ---------------------------------------------------------------------------

export type AgingBucket = "current" | "1-30" | "31-60" | "61-90" | "90+";

export function agingBucket(dueDate: Date, asOf: Date): AgingBucket {
  const daysOverdue = Math.floor((asOf.getTime() - dueDate.getTime()) / 86_400_000);
  if (daysOverdue <= 0) return "current";
  if (daysOverdue <= 30) return "1-30";
  if (daysOverdue <= 60) return "31-60";
  if (daysOverdue <= 90) return "61-90";
  return "90+";
}

export function agingSchedule(
  invoices: Pick<Invoice, "amount" | "amountPaid" | "dueDate">[],
  asOf: Date
): Record<AgingBucket, number> {
  const buckets: Record<AgingBucket, number> = {
    current: 0,
    "1-30": 0,
    "31-60": 0,
    "61-90": 0,
    "90+": 0,
  };
  for (const inv of invoices) {
    const outstanding = inv.amount - inv.amountPaid;
    if (outstanding <= 0) continue;
    buckets[agingBucket(inv.dueDate, asOf)] += outstanding;
  }
  for (const key of Object.keys(buckets) as AgingBucket[]) {
    buckets[key] = round2(buckets[key]);
  }
  return buckets;
}

/** Customer payment reliability: % of invoices historically paid within terms. */
export function paymentReliability(paidOnTime: number, totalPaidInvoices: number): number {
  if (totalPaidInvoices === 0) return 0;
  return round1((paidOnTime / totalPaidInvoices) * 100);
}

export function avgPaymentDelayDays(delaysInDays: number[]): number {
  if (delaysInDays.length === 0) return 0;
  return round1(delaysInDays.reduce((s, d) => s + d, 0) / delaysInDays.length);
}

// ---------------------------------------------------------------------------
// Business Health Score (0-100)
// ---------------------------------------------------------------------------

export interface HealthScoreInputs {
  cashRunwayDays: number | null; // null = not burning cash
  grossMarginPct: number;
  currentRatio: number;
  receivableDaysTrendDelta: number; // positive = getting worse
  debtServiceCoverageRatio: number;
  customerConcentrationPct: number; // % revenue from top customer
  inventoryDaysTrendDelta: number; // positive = getting worse
  revenueGrowthPct: number;
}

export interface HealthScoreBreakdown {
  score: number;
  components: {
    cashFlow: number;
    profitability: number;
    liquidity: number;
    receivables: number;
    debt: number;
    customerConcentration: number;
    inventory: number;
    growth: number;
  };
}

/**
 * Weighted composite score. Each component is scored 0-100 on its own scale,
 * then combined by weight. Weights sum to 1.0 and were chosen to reflect
 * what most threatens an MSME first: cash, then margin, then structural risk.
 */
export function businessHealthScore(inputs: HealthScoreInputs): HealthScoreBreakdown {
  const weights = {
    cashFlow: 0.25,
    profitability: 0.2,
    liquidity: 0.12,
    receivables: 0.13,
    debt: 0.1,
    customerConcentration: 0.08,
    inventory: 0.07,
    growth: 0.05,
  };

  const cashFlow =
    inputs.cashRunwayDays === null
      ? 100
      : clamp(scaleLinear(inputs.cashRunwayDays, 0, 90, 0, 100), 0, 100);

  const profitability = clamp(scaleLinear(inputs.grossMarginPct, 5, 40, 0, 100), 0, 100);
  const liquidity = clamp(scaleLinear(inputs.currentRatio, 0.5, 2, 0, 100), 0, 100);
  const receivables = clamp(100 - scaleLinear(inputs.receivableDaysTrendDelta, 0, 30, 0, 100), 0, 100);
  const debt = clamp(scaleLinear(inputs.debtServiceCoverageRatio, 0.5, 3, 0, 100), 0, 100);
  const customerConcentration = clamp(
    100 - scaleLinear(inputs.customerConcentrationPct, 15, 60, 0, 100),
    0,
    100
  );
  const inventory = clamp(100 - scaleLinear(inputs.inventoryDaysTrendDelta, 0, 30, 0, 100), 0, 100);
  const growth = clamp(scaleLinear(inputs.revenueGrowthPct, -10, 25, 0, 100), 0, 100);

  const components = {
    cashFlow,
    profitability,
    liquidity,
    receivables,
    debt,
    customerConcentration,
    inventory,
    growth,
  };

  const score = Math.round(
    Object.entries(components).reduce(
      (sum, [key, value]) => sum + value * weights[key as keyof typeof weights],
      0
    )
  );

  return { score: clamp(score, 0, 100), components };
}

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

/** Linear-scales `value` from [inMin,inMax] to [outMin,outMax], extrapolating outside the range. */
function scaleLinear(value: number, inMin: number, inMax: number, outMin: number, outMax: number): number {
  if (inMax === inMin) return outMin;
  const t = (value - inMin) / (inMax - inMin);
  return outMin + t * (outMax - outMin);
}
