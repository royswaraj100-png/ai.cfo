import { prisma } from "../db/client";

export interface PayableRow {
  invoiceId: string;
  supplierName: string;
  poNumber: string;
  dueDate: Date;
  amountDue: number;
  priority: "critical" | "standard" | "flexible";
  cashImpact: "high" | "medium" | "low";
  /**
   * Whether this payment could reasonably be delayed a short time without breaching
   * contract terms or harming a relationship the business depends on. This is a
   * heuristic based on declared supplier priority, not a legal or ethical judgment —
   * the UI must always label it as a suggestion for the owner's own judgment, never
   * as an instruction, and it must never apply to statutory dues (GST, TDS, PF, ESI).
   */
  possiblyDeferrable: boolean;
}

export async function getPayablesTable(businessId: string): Promise<PayableRow[]> {
  const invoices = await prisma.invoice.findMany({
    where: { businessId, type: "PURCHASE", status: { in: ["OPEN", "PARTIALLY_PAID", "OVERDUE"] } },
    include: { supplier: true },
    orderBy: { dueDate: "asc" },
  });

  return invoices.map((inv) => {
    const amountDue = Number(inv.amount) - Number(inv.amountPaid);
    const priority = (inv.supplier?.priority as PayableRow["priority"]) ?? "standard";
    const cashImpact: PayableRow["cashImpact"] = amountDue > 150000 ? "high" : amountDue > 50000 ? "medium" : "low";

    return {
      invoiceId: inv.id,
      supplierName: inv.supplier?.name ?? "Unknown",
      poNumber: inv.number,
      dueDate: inv.dueDate,
      amountDue: Math.round(amountDue * 100) / 100,
      priority,
      cashImpact,
      // Only ever "flexible"-priority, non-overdue supplier bills are flagged —
      // never critical suppliers, and never anything already overdue (deferring
      // something already late compounds risk rather than buying safe time).
      possiblyDeferrable: priority === "flexible" && inv.status !== "OVERDUE",
    };
  });
}

export async function getPayablesSummary(businessId: string) {
  const rows = await getPayablesTable(businessId);
  const totalDue = rows.reduce((s, r) => s + r.amountDue, 0);
  const deferrableAmount = rows.filter((r) => r.possiblyDeferrable).reduce((s, r) => s + r.amountDue, 0);
  return {
    totalDue: Math.round(totalDue * 100) / 100,
    deferrableAmount: Math.round(deferrableAmount * 100) / 100,
    supplierCount: new Set(rows.map((r) => r.supplierName)).size,
  };
}
