export type Role = "OWNER" | "ADMIN" | "CFO" | "ACCOUNTANT" | "FINANCE_MANAGER" | "VIEWER";

export type Permission =
  | "view:dashboard"
  | "view:financials"
  | "edit:financials"
  | "manage:users"
  | "manage:integrations"
  | "use:ai-cfo"
  | "export:reports"
  | "manage:billing";

const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  OWNER: [
    "view:dashboard",
    "view:financials",
    "edit:financials",
    "manage:users",
    "manage:integrations",
    "use:ai-cfo",
    "export:reports",
    "manage:billing",
  ],
  ADMIN: [
    "view:dashboard",
    "view:financials",
    "edit:financials",
    "manage:users",
    "manage:integrations",
    "use:ai-cfo",
    "export:reports",
  ],
  CFO: ["view:dashboard", "view:financials", "edit:financials", "use:ai-cfo", "export:reports"],
  FINANCE_MANAGER: ["view:dashboard", "view:financials", "edit:financials", "use:ai-cfo", "export:reports"],
  ACCOUNTANT: ["view:dashboard", "view:financials", "edit:financials", "export:reports"],
  VIEWER: ["view:dashboard", "view:financials"],
};

export function hasPermission(role: Role, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role]?.includes(permission) ?? false;
}

export function requirePermission(role: Role, permission: Permission): void {
  if (!hasPermission(role, permission)) {
    throw new Error(`FORBIDDEN: role ${role} lacks permission ${permission}`);
  }
}
