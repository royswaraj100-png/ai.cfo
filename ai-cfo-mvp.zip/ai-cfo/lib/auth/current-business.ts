import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { prisma } from "../db/client";
import { verifySessionToken, SESSION_COOKIE_NAME } from "./session";

/**
 * Resolves which business the current session should see data for.
 * Falls back to the user's first business membership if none is set.
 * Redirects to /login if there is no valid session.
 */
export async function getActiveBusinessId(): Promise<string> {
  const token = cookies().get(SESSION_COOKIE_NAME)?.value;
  const session = token ? await verifySessionToken(token) : null;
  if (!session) redirect("/login");

  if (session.activeBusinessId) return session.activeBusinessId;

  const membership = await prisma.businessMember.findFirst({
    where: { userId: session.userId },
    orderBy: { createdAt: "asc" },
  });
  if (!membership) redirect("/onboarding");

  return membership.businessId;
}
