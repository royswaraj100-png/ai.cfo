/**
 * Demo Data Seed — "ABC Manufacturing Pvt Ltd"
 * ---------------------------------------------
 * Populates a full 12-month operating history for a manufacturing business
 * with ~₹12.4 crore annual revenue, so the whole app works immediately in
 * demo mode with zero setup. Run with: npm run db:seed
 */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import * as calc from "../lib/finance/calculations";

const prisma = new PrismaClient();

const CUSTOMER_NAMES = [
  "Sharma Textiles", "Vishal Auto Components", "Kanha Distributors", "Om Sai Traders",
  "Bharat Fasteners", "Reliable Steel Co", "Nova Pharma Distribution", "Greenfield Agro",
  "Precision Tooling Ltd", "Sunrise Electricals", "Metro Hardware", "Everest Logistics Supply",
  "Kalyan Enterprises", "Shakti Engineering", "Aditya Plastics", "Continental Fasteners",
  "Vinayak Traders", "Skyline Components", "United Bearings", "Sunflower FMCG",
  "Ganga Industrial", "Pioneer Auto Parts", "Radha Krishna Steels", "Falcon Manufacturing",
  "Diamond Distributors",
];

const SUPPLIER_NAMES = Array.from({ length: 42 }, (_, i) => `Supplier ${i + 1} Pvt Ltd`);

const PRODUCTS = [
  { name: "Precision Bracket A1", unitCost: 180, unitPrice: 260 },
  { name: "Steel Hinge B2", unitCost: 95, unitPrice: 145 },
  { name: "Auto Clamp C3", unitCost: 220, unitPrice: 310 },
  { name: "Industrial Bolt Set D4", unitCost: 60, unitPrice: 95 },
  { name: "Machined Housing E5", unitCost: 410, unitPrice: 590 },
];

function daysAgo(n: number): Date {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d;
}

function randomBetween(min: number, max: number): number {
  return Math.round(min + Math.random() * (max - min));
}

async function main() {
  console.log("Seeding demo company: ABC Manufacturing Pvt Ltd...");

  // ---- User + Business -----------------------------------------------
  const passwordHash = await bcrypt.hash("Demo@1234", 12);
  const owner = await prisma.user.upsert({
    where: { email: "owner@abcmanufacturing.demo" },
    update: {},
    create: { email: "owner@abcmanufacturing.demo", name: "Rajesh Gupta", passwordHash },
  });

  const business = await prisma.business.create({
    data: {
      name: "ABC Manufacturing Pvt Ltd",
      industry: "Auto-component manufacturing",
      annualRevenueBand: "1cr-25cr",
      location: "Pune, Maharashtra",
      employeeCount: 78,
      accountingSoftware: "Tally",
      primaryBank: "HDFC Bank",
      gstin: "27ABCDE1234F1Z5",
      isDemo: true,
      members: { create: { userId: owner.id, role: "OWNER" } },
    },
  });

  // ---- Customers / Suppliers / Products --------------------------------
  const customers = await Promise.all(
    CUSTOMER_NAMES.map((name) =>
      prisma.customer.create({
        data: {
          businessId: business.id,
          name,
          creditDays: [30, 45, 60][randomBetween(0, 2)],
          segment: "B2B",
        },
      })
    )
  );

  const suppliers = await Promise.all(
    SUPPLIER_NAMES.map((name, i) =>
      prisma.supplier.create({
        data: {
          businessId: business.id,
          name,
          priority: i < 8 ? "critical" : i < 25 ? "standard" : "flexible",
          category: "Raw materials",
        },
      })
    )
  );

  const products = await Promise.all(
    PRODUCTS.map((p) => prisma.product.create({ data: { businessId: business.id, ...p } }))
  );

  // ---- 12 months of sales invoices --------------------------------------
  let invoiceCounter = 1000;
  const salesInvoices: { id: string; amount: number; amountPaid: number; dueDate: Date }[] = [];

  for (let monthOffset = 11; monthOffset >= 0; monthOffset--) {
    const invoicesThisMonth = randomBetween(18, 28);
    for (let i = 0; i < invoicesThisMonth; i++) {
      const customer = customers[randomBetween(0, customers.length - 1)];
      const invoiceDate = daysAgo(monthOffset * 30 + randomBetween(0, 27));
      const dueDate = new Date(invoiceDate);
      dueDate.setDate(dueDate.getDate() + [30, 45, 60][randomBetween(0, 2)]);

      const lineCount = randomBetween(1, 3);
      const lines = Array.from({ length: lineCount }, () => {
        const product = products[randomBetween(0, products.length - 1)];
        const quantity = randomBetween(20, 400);
        return { product, quantity, unitPrice: Number(product.unitPrice), unitCost: Number(product.unitCost) };
      });
      const amount = calc.revenue(lines.map((l) => ({ quantity: l.quantity, unitPrice: l.unitPrice, unitCost: l.unitCost })));

      // Payment behavior: most pay within terms, some late, a few still open
      const isPaid = monthOffset > 1 ? Math.random() > 0.08 : Math.random() > 0.55;
      const amountPaid = isPaid ? amount : Math.random() > 0.5 ? Math.round(amount * randomBetween(30, 70) / 100) : 0;
      const status = amountPaid >= amount ? "PAID" : amountPaid > 0 ? "PARTIALLY_PAID" : dueDate < new Date() ? "OVERDUE" : "OPEN";

      const invoice = await prisma.invoice.create({
        data: {
          businessId: business.id,
          type: "SALES",
          number: `INV-${invoiceCounter++}`,
          customerId: customer.id,
          invoiceDate,
          dueDate,
          amount,
          amountPaid,
          status,
          items: {
            create: lines.map((l) => ({
              productId: l.product.id,
              description: l.product.name,
              quantity: l.quantity,
              unitPrice: l.unitPrice,
              unitCost: l.unitCost,
              lineTotal: Math.round(l.quantity * l.unitPrice * 100) / 100,
            })),
          },
        },
      });
      salesInvoices.push({ id: invoice.id, amount, amountPaid, dueDate });

      if (amountPaid > 0) {
        await prisma.payment.create({
          data: {
            businessId: business.id,
            invoiceId: invoice.id,
            direction: "INBOUND",
            amount: amountPaid,
            paidOn: new Date(Math.min(Date.now(), dueDate.getTime() + randomBetween(-5, 20) * 86_400_000)),
            method: ["NEFT", "UPI", "Cheque"][randomBetween(0, 2)],
          },
        });
      }
    }
  }

  // ---- 12 months of purchase invoices (payables) ------------------------
  for (let monthOffset = 11; monthOffset >= 0; monthOffset--) {
    const invoicesThisMonth = randomBetween(15, 22);
    for (let i = 0; i < invoicesThisMonth; i++) {
      const supplier = suppliers[randomBetween(0, suppliers.length - 1)];
      const invoiceDate = daysAgo(monthOffset * 30 + randomBetween(0, 27));
      const dueDate = new Date(invoiceDate);
      dueDate.setDate(dueDate.getDate() + 30);
      const amount = randomBetween(15000, 220000);
      const isPaid = monthOffset > 1 ? Math.random() > 0.1 : Math.random() > 0.6;
      const amountPaid = isPaid ? amount : 0;
      const status = amountPaid >= amount ? "PAID" : dueDate < new Date() ? "OVERDUE" : "OPEN";

      await prisma.invoice.create({
        data: {
          businessId: business.id,
          type: "PURCHASE",
          number: `PO-${invoiceCounter++}`,
          supplierId: supplier.id,
          invoiceDate,
          dueDate,
          amount,
          amountPaid,
          status,
        },
      });
    }
  }

  // ---- Expenses -----------------------------------------------------------
  const expenseCategories = ["Payroll", "Rent", "Utilities", "Marketing", "Logistics", "Maintenance", "Insurance"];
  for (let monthOffset = 11; monthOffset >= 0; monthOffset--) {
    for (const category of expenseCategories) {
      const base: Record<string, [number, number]> = {
        Payroll: [1800000, 1950000],
        Rent: [180000, 180000],
        Utilities: [90000, 140000],
        Marketing: [40000, 90000],
        Logistics: [120000, 190000],
        Maintenance: [30000, 80000],
        Insurance: [25000, 25000],
      };
      const [min, max] = base[category];
      await prisma.expense.create({
        data: {
          businessId: business.id,
          category,
          amount: randomBetween(min, max),
          incurredOn: daysAgo(monthOffset * 30 + randomBetween(1, 25)),
        },
      });
    }
  }

  // ---- Bank transactions + running balance --------------------------------
  let balance = 2200000;
  for (let d = 364; d >= 0; d--) {
    const date = daysAgo(d);
    const hasActivity = Math.random() > 0.55;
    if (!hasActivity) continue;
    const isCredit = Math.random() > 0.45;
    const amount = isCredit ? randomBetween(20000, 450000) : -randomBetween(15000, 380000);
    balance += amount;
    await prisma.bankTransaction.create({
      data: {
        businessId: business.id,
        txnDate: date,
        description: isCredit ? "Customer payment received" : "Supplier / expense payment",
        amount,
        balanceAfter: balance,
        category: isCredit ? "collection" : "payment",
      },
    });
  }

  // Force the final balance to match the demo brief (₹18.7L)
  const finalBalance = 1870000;
  await prisma.bankTransaction.create({
    data: {
      businessId: business.id,
      txnDate: new Date(),
      description: "Balancing adjustment",
      amount: finalBalance - balance,
      balanceAfter: finalBalance,
      category: "adjustment",
    },
  });

  // ---- Loan --------------------------------------------------------------
  await prisma.loan.create({
    data: {
      businessId: business.id,
      lender: "HDFC Bank — Term Loan",
      principal: 9000000,
      outstanding: 7200000,
      interestRate: 11.5,
      emiAmount: 185000,
      nextDueDate: daysAgo(-12),
      tenureMonths: 60,
    },
  });

  // ---- Inventory -----------------------------------------------------------
  for (const product of products) {
    await prisma.inventoryItem.create({
      data: {
        businessId: business.id,
        productId: product.id,
        quantityOnHand: randomBetween(500, 4000),
        avgUnitCost: product.unitCost,
      },
    });
  }

  // ---- Employees (sample of 78) -------------------------------------------
  const roles = ["Machine Operator", "Supervisor", "Quality Inspector", "Accounts", "Sales Executive", "Logistics"];
  for (let i = 0; i < 78; i++) {
    await prisma.employee.create({
      data: {
        businessId: business.id,
        name: `Employee ${i + 1}`,
        role: roles[randomBetween(0, roles.length - 1)],
        monthlySalary: randomBetween(18000, 65000),
        joinedOn: daysAgo(randomBetween(60, 1500)),
      },
    });
  }

  // ---- Financial metrics (rolled up per month, last 12 months) ------------
  for (let monthOffset = 11; monthOffset >= 0; monthOffset--) {
    const periodEnd = daysAgo(monthOffset * 30);
    const periodStart = daysAgo(monthOffset * 30 + 30);
    const revenue = randomBetween(950000, 1150000);
    const cogsValue = Math.round(revenue * (0.62 + Math.random() * 0.08));
    const grossProfit = calc.grossProfit(revenue, cogsValue);
    const grossMargin = calc.grossMarginPct(revenue, cogsValue);
    const opex = randomBetween(220000, 280000);
    const ebitdaValue = calc.ebitda(grossProfit, opex);
    const receivables = randomBetween(4800000, 6800000);
    const payables = randomBetween(3200000, 4600000);
    const inventoryValue = randomBetween(4000000, 5200000);
    const cashBalance = randomBetween(1200000, 2400000);
    const workingCapital = calc.workingCapital(receivables + inventoryValue, payables);
    const dso = calc.receivableDays(receivables, revenue, 30);
    const dpo = calc.payableDays(payables, cogsValue, 30);
    const dio = calc.inventoryDays(inventoryValue, cogsValue, 30);
    const ccc = calc.cashConversionCycle(dio, dso, dpo);

    const { score } = calc.businessHealthScore({
      cashRunwayDays: null,
      grossMarginPct: grossMargin,
      currentRatio: calc.currentRatio(receivables + inventoryValue + cashBalance, payables),
      receivableDaysTrendDelta: randomBetween(-3, 8),
      debtServiceCoverageRatio: calc.debtServiceCoverageRatio(ebitdaValue * 12, 185000 * 12),
      customerConcentrationPct: randomBetween(12, 28),
      inventoryDaysTrendDelta: randomBetween(-3, 10),
      revenueGrowthPct: randomBetween(-4, 18),
    });

    await prisma.financialMetric.create({
      data: {
        businessId: business.id,
        periodStart,
        periodEnd,
        revenue,
        cogs: cogsValue,
        grossProfit,
        grossMargin,
        ebitda: ebitdaValue,
        cashBalance,
        receivables,
        payables,
        inventoryValue,
        debtOutstanding: 7200000,
        workingCapital,
        cashConversionCycleDays: ccc,
        healthScore: score,
      },
    });
  }

  // ---- Cash flow forecasts (30-day, all 3 scenarios) -----------------------
  const scenarios: { scenario: "BASE" | "OPTIMISTIC" | "STRESS"; collectionFactor: number }[] = [
    { scenario: "BASE", collectionFactor: 1.0 },
    { scenario: "OPTIMISTIC", collectionFactor: 1.15 },
    { scenario: "STRESS", collectionFactor: 0.8 },
  ];
  for (const { scenario, collectionFactor } of scenarios) {
    let opening = 1870000;
    for (let day = 1; day <= 90; day++) {
      const collections = Math.round(randomBetween(60000, 140000) * collectionFactor);
      const payments = randomBetween(70000, 130000);
      const payroll = day % 30 === 1 ? 1850000 : 0;
      const loanPayment = day % 30 === 12 ? 185000 : 0;
      const taxes = day % 30 === 20 ? randomBetween(80000, 160000) : 0;
      const opex = randomBetween(8000, 20000);
      const closing = opening + collections - payments - payroll - loanPayment - taxes - opex;

      await prisma.cashFlowForecast.create({
        data: {
          businessId: business.id,
          scenario,
          forecastDate: daysAgo(-day),
          openingCash: opening,
          expectedCollections: collections,
          expectedPayments: payments,
          loanPayments: loanPayment,
          payroll,
          taxes,
          operatingExpenses: opex,
          closingCash: closing,
        },
      });
      opening = closing;
    }
  }

  // ---- Insights (AI-generated findings, pre-seeded for demo) --------------
  await prisma.insight.createMany({
    data: [
      {
        businessId: business.id,
        title: "Cash deficit expected in 18 days",
        finding: "Under the base-case forecast, closing cash turns negative around day 18.",
        reason: "Payroll and the HDFC term loan EMI both fall in the same week as a dip in expected collections.",
        impact: "Estimated shortfall of ₹3.2L on that date if collections don't improve.",
        recommendation: "Follow up on the two largest overdue receivables now, or arrange a short-term credit line before day 18.",
        severity: "CRITICAL",
        category: "cash",
      },
      {
        businessId: business.id,
        title: "Sharma Textiles has ₹12.4L overdue",
        finding: "Sharma Textiles' outstanding balance is 46 days past due.",
        reason: "Their average payment delay has grown from 12 to 23 days over the last two quarters.",
        impact: "This single customer accounts for a meaningful share of your 90+ day receivables bucket.",
        recommendation: "Send a payment reminder and consider tightening credit terms for future orders.",
        severity: "WARNING",
        category: "receivables",
      },
      {
        businessId: business.id,
        title: "Gross margin declined 2.1%",
        finding: "Gross margin fell from 34.1% to 32.0% this month.",
        reason: "Raw material cost increased on your top-selling SKU while selling price stayed flat.",
        impact: "At current volumes, this costs roughly ₹1.8L in gross profit per month.",
        recommendation: "Review pricing on the affected SKU or renegotiate with the supplier.",
        severity: "WARNING",
        category: "margin",
      },
      {
        businessId: business.id,
        title: "Inventory increased 16%",
        finding: "Inventory value is up 16% versus last quarter while sales grew only 6%.",
        reason: "Slower-moving SKUs are accumulating stock faster than they're selling.",
        impact: "Cash is tied up in inventory, lengthening the cash conversion cycle.",
        recommendation: "Review reorder quantities for the slowest-moving products.",
        severity: "INFO",
        category: "inventory",
      },
    ],
  });

  // ---- Mock integrations ----------------------------------------------------
  await prisma.integration.createMany({
    data: [
      { businessId: business.id, provider: "GST", status: "MOCK_CONNECTED" },
      { businessId: business.id, provider: "BANK_ACCOUNT_AGGREGATOR", status: "MOCK_CONNECTED" },
      { businessId: business.id, provider: "TALLY", status: "MOCK_CONNECTED" },
      { businessId: business.id, provider: "ZOHO_BOOKS", status: "NOT_CONNECTED" },
      { businessId: business.id, provider: "ERP", status: "NOT_CONNECTED" },
    ],
  });

  console.log(`Done. Demo login: owner@abcmanufacturing.demo / Demo@1234 (businessId: ${business.id})`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
